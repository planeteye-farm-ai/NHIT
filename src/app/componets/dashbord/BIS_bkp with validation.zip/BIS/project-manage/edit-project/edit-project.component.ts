import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-project',
  standalone: true,
  imports: [],
  templateUrl: './edit-project.component.html',
  styleUrl: './edit-project.component.scss'
})
export class EditProjectComponent {

}
