import { Component } from '@angular/core';

@Component({
  selector: 'app-view-project',
  standalone: true,
  imports: [],
  templateUrl: './view-project.component.html',
  styleUrl: './view-project.component.scss'
})
export class ViewProjectComponent {

}
