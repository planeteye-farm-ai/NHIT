import { Component } from '@angular/core';

@Component({
  selector: 'app-bis-testing',
  standalone: true,
  imports: [],
  templateUrl: './bis-testing.component.html',
  styleUrl: './bis-testing.component.scss'
})
export class BisTestingComponent {

}
