import { Component,ViewChild, ElementRef } from '@angular/core';
import { ShowcodeCardComponent } from '../../../../../shared/common/includes/showcode-card/showcode-card.component';
import * as prismCodeData from '../../../../../shared/prismData/tables';
import { SharedModule } from '../../../../../shared/common/sharedmodule';
import { NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {NgbModalConfig} from '@ng-bootstrap/ng-bootstrap';
import { NgbPopoverModule } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormsModule} from '@angular/forms';
import {ToastrService } from 'ngx-toastr';
import { NgSelectModule } from '@ng-select/ng-select';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { BridgeService } from '.././bridge.service';
import * as XLSX from 'xlsx';
import { jsPDF } from "jspdf";
import autoTable from 'jspdf-autotable';
import { ApiUrl } from '../../../../../shared/const';


@Component({
  selector: 'app-inspection',
  standalone: true,
  imports: [SharedModule,NgSelectModule,NgbPopoverModule,FormsModule,RouterLink,ShowcodeCardComponent],
  templateUrl: './inspection.component.html',
  styleUrl: './inspection.component.scss'
})
export class InspectionComponent {
   urlLive = ApiUrl.API_URL_fOR_iMAGE;
  prismCode = prismCodeData;
  content:any;
  tableData:any;
  selectedId: number | null = null;
  bridgeId:any;
  bridgeData:any;
  bridgeName:any;
  fileName:any;
  insepectionData:any
  constructor( private route: ActivatedRoute,config: NgbModalConfig, private modalService: NgbModal,private toastr: ToastrService,private bridgeService:BridgeService){
  }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
     this.bridgeId = Number(params.get('id'));
    });

    this.getBridgeDetailsById()
    this.getInspectionData();
  }

  getInspectionData(){
    this.bridgeService.getInspectionByBridgeId(this.bridgeId).subscribe((res)=>{
      this.tableData = res.data;
      // console.log(res.data)
    })
  }

  getBridgeDetailsById(){
    this.bridgeService.getDetailsById(this.bridgeId).subscribe((res) => {
      this.bridgeData = res.data;
      // console.log("bridge details",this.bridgeData);
      this.bridgeName = this.bridgeData.popular_name_of_bridge
      this.fileName = `Inspection List of ${this.bridgeName}.xlsx`;
    });
  }

  delete(){
    if (this.selectedId !== null) {
      this.bridgeService.deleteInspection(this.selectedId).subscribe((res)=>{
        // console.log(res)
        if(res.status){
          this.getInspectionData();
          this.toastr.success(res.msg, 'NHAI RAMS', {
            timeOut: 3000,
            positionClass: 'toast-top-right',
          });
        }
        else{
          this.toastr.error(res.msg, 'NHAI RAMS', {
            timeOut: 3000,
            positionClass: 'toast-top-right',
          });
        }
      },(err)=>{
        this.toastr.error(err.msg, 'NHAI RAMS', {
          timeOut: 3000,
          positionClass: 'toast-top-right',
        });
      });
    }
  }

  open(content: any,id:any) {
    this.selectedId = id;
    this.modalService.open(content);
  }

   excelExport(){
      let data = document.getElementById('inspectionListExport');
    const ws:XLSX.WorkSheet = XLSX.utils.table_to_sheet(data);
    const wscols = [
      { wpx: 150 }, // Date	
      { wpx: 100 }, // Created By
      { wpx: 200 }, // Duration
    ];
  
    ws['!cols'] = wscols;
  
    const wb:XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb,ws,'Sheet1')
  
    XLSX.writeFile(wb,this.fileName);
    }


loadInspectionData(inspection_id:number){
  this.bridgeService.getInspectionById(inspection_id).subscribe((inspection: any) => {
    if (inspection) {
      this.insepectionData = inspection.data;
      this.generatePDF(this.insepectionData);
        // console.log(this.insepectionData)
    }
  }, (err) => {
    this.toastr.error(err.msg, 'NHAI RAMS', {
      timeOut: 3000,
      positionClass: 'toast-top-right',
    });
  });
}

generatePDF(insepectionData: any): void {
  const doc = new jsPDF();

  // Header: Inspection Report Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text(`Inspection Report of ${this.insepectionData.popular_name_of_bridge || 'Bridge'}`, doc.internal.pageSize.getWidth() / 2, 20, { align: 'center' });

  // Add inspection details dynamically
  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  let currentY = 35;

  doc.text(`Bridge Name = ${this.insepectionData.popular_name_of_bridge || 'N/A'}`, 14, currentY);
  currentY += 10;
  doc.text(`Road/ Highway No = ${this.insepectionData.highway_no || 'N/A'}`, 14, currentY);
  currentY += 10;
  doc.text(`Type of Bridge = ${this.insepectionData.type_of_Bridge || 'N/A'}`, 14, currentY);
  currentY += 10;
  doc.text(`Duration Of Inspection = ${this.insepectionData.duration_of_inspection || 'N/A'}`, 14, currentY);
  currentY += 10;
  doc.text(`Erosion Embankment = ${this.insepectionData.erosion_of_embankment || 'N/A'}`, 14, currentY);
  currentY += 5;

  if (this.insepectionData.erosion_of_embankment_image) {
     const imageData = this.urlLive+"/upload/inspection_images/"+this.insepectionData.erosion_of_embankment_image; 
     const encodedImageUrl = encodeURI(imageData);
    console.log(encodedImageUrl);
    doc.addImage(encodedImageUrl, 'JPEG', 14, currentY, 65, 45); // Adjust position and size
    currentY += 50; // Move Y position down **before adding new text**
  }

  doc.text(`Approach Slab = ${this.insepectionData.approach_slab || 'N/A'}`, 14, currentY);
  currentY += 10; // Move down for any next content

  // Save the PDF
  doc.save(`Inspection Report of ${this.insepectionData.popular_name_of_bridge || 'Bridge'}.pdf`);
}


}
