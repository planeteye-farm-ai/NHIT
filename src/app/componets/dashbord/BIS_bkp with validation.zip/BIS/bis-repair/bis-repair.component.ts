import { Component } from '@angular/core';

@Component({
  selector: 'app-bis-repair',
  standalone: true,
  imports: [],
  templateUrl: './bis-repair.component.html',
  styleUrl: './bis-repair.component.scss'
})
export class BisRepairComponent {

}
